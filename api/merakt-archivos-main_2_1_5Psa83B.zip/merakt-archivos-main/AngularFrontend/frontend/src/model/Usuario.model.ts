export class Usuario {
    id: number;
    nombres: string;
    apellidos: string;
    email: string;
    password: string;
    fecha: Date;
}